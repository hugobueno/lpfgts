const light = {
    title: 'light',
    colors: {
        primary: '#6AD59D',
        secundary: '#216DFA',
        ternary: '#8A6EF0',
        quaternary: '#00b894',
        background: '#f2f2f2',
        background_gray: '#F4F4F4',
        text: '#272727',
        text_button: '#272727',
        text_light: '#ffffff',
        border: '#dfe5f2'
    }
}

export default light